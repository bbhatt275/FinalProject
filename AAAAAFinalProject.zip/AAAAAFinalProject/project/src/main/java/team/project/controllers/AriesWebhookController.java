package team.project.controllers;

// AriesWebhookController.java

import team.project.entity.Student;
import team.project.repository.StudentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import team.project.service.AriesService;

import java.util.Map;
import java.util.Optional;

@RestController // Use @RestController for API endpoints that don't return HTML views
public class AriesWebhookController {

	private static final Logger log = LoggerFactory.getLogger(AriesWebhookController.class);
	@Autowired
	private AriesService ariesService;
	@Autowired
	private StudentRepository studentRepository;

	/**
	 * This is the main webhook endpoint that ACA-Py will call.
	 * It's defined by the --webhook-url http://host.docker.internal:8080/webhooks
	 * ACA-Py automatically adds the "/topic/{topic_name}" to the end.
	 */
	@PostMapping({"/webhooks/topic/{topic}","/webhooks/topic/{topic}/"})
	public ResponseEntity<String> handleWebhook(@PathVariable String topic, @RequestBody Map<String, Object> payload) {

		// Log the raw payload for debugging (can be very noisy)
		// log.info("Webhook received for topic [{}]: {}", topic, payload);

		try {
			switch (topic) {
				case "connections":
					handleConnectionWebhook(payload);
					break;
				case "issue_credential_v2_0":
					handleCredentialWebhook(payload);
					break;
				// Add other topics like "present_proof" later
				default:
					log.warn("Received webhook for unhandled topic: {}", topic);
			}
		} catch (Exception e) {
			log.error("Error processing webhook for topic: {}", topic, e);
			// Even if we fail, tell the agent we received it to prevent retries
		}

		// IMPORTANT: Always return a 200 OK to ACA-Py
		// This acknowledges receipt of the webhook.
		return ResponseEntity.ok("Webhook received successfully");
	}

	/**
	 * Handles webhooks related to the 'connections' topic.
	 */
	private void handleConnectionWebhook(Map<String, Object> payload) {
		String connectionId = (String) payload.get("connection_id");
		String state = (String) payload.get("state");
		String alias = (String) payload.get("alias"); // e.g., student id or name

		log.info("Connection Webhook: ID={} | State={} | Alias={}", connectionId, state, alias);

		switch (state) {
			case "request":
				log.info("Connection request received. Accepting automatically for connection ID {}", connectionId);
				ariesService.acceptConnectionRequest(connectionId); // <-- call ACA-Py endpoint to accept request
				break;

			case "active":
				log.info("Connection ID {} is now ACTIVE", connectionId);
				Optional<Student> studentOptional = studentRepository.findByConnectionId(connectionId);

				if (studentOptional.isEmpty() && alias != null) {
					log.warn("Student not found by connectionId {}. Fallback to alias(student id) '{}'", connectionId, alias);
					studentOptional = studentRepository.findById(Long.parseLong(alias));
				}

				studentOptional.ifPresent(student -> {
					student.setConnectionId(connectionId);
					studentRepository.save(student);
					log.info("Connection saved for student {}", student.getName());
				});
				break;

			default:
				log.info("Unhandled connection state: {}", state);
		}
	}

	/**
	 * Handles webhooks related to the 'issue_credential' topic.
	 * (We will use this in the next step after clicking "Issue Degree")
	 */
	private void handleCredentialWebhook(Map<String, Object> payload) {
		String state = (String) payload.get("state");
		String connectionId = (String) payload.get("connection_id");
		String credentialExchangeId = (String) payload.get("cred_ex_id");
		String role = (String) payload.get("role");
		log.info("Credential Webhook: ConnID={} | State={} | ExID={}", connectionId, state, credentialExchangeId);

		// This is the final step of issuance
		if("request-received".equals(state)){
			if ("issuer".equals(role)) {
				log.info("Credential request received — issuing credential for exchange ID {}", credentialExchangeId);
				try {
					ariesService.issueCredential(credentialExchangeId);
				} catch (Exception e) {
					log.error("Failed to issue credential for exchange ID {}: {}", credentialExchangeId, e.getMessage());
				}
			}
		}
		if ("credential-acked".equals(state) || "credential-issued".equals(state)) {
			// Find the student associated with this connection
			Optional<Student> studentOptional = studentRepository.findByConnectionId(connectionId);

			if (studentOptional.isPresent()) {
				Student student = studentOptional.get();
				student.setDegreeIssued(true); // Mark the degree as issued in our database!
				studentRepository.save(student);
				log.info("Successfully issued credential to student: {}", student.getName());
			} else {
				log.warn("Received 'credential_acked' webhook for connection ID {} but no matching student found.", connectionId);
			}
		}
	}
}