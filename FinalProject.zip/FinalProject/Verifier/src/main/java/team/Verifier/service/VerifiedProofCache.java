package team.Verifier.service;

import org.springframework.stereotype.Component;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A simple in-memory, non-persistent cache to hold verified proof data.
 * Key: connectionId
 * Value: Map<String, String> of verified attributes (e.g., "name" -> "Alice Smith")
 */
@Component
public class VerifiedProofCache {

	// A static map to hold data across requests.
	// Use ConcurrentHashMap for basic thread safety.
	private static final Map<String, Map<String, String>> proofCache = new ConcurrentHashMap<>();

	public void storeProof(String connectionId, Map<String, String> attributes) {
		proofCache.put(connectionId, attributes);
	}

	public Map<String, String> getProof(String connectionId) {
		return proofCache.get(connectionId);
	}

	public void clearProof(String connectionId) {
		proofCache.remove(connectionId);
	}
}