package team.Verifier.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@Service
public class VerifierAriesService {

	private static final Logger log = LoggerFactory.getLogger(VerifierAriesService.class);

	@Autowired
	private VerifiedProofCache proofCache;
	private final RestTemplate restTemplate;

	@Value("${acapy.admin.url}")
	private String acapyAdminUrl;

	@Value("${acapy.admin.api-key}")
	private String acapyAdminApiKey;

	public VerifierAriesService(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	private HttpHeaders createHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("X-API-Key", acapyAdminApiKey);
		headers.setContentType(MediaType.APPLICATION_JSON);
		return headers;
	}

	// Creates an invitation to connect with a student
	public Map<String, Object> createConnectionInvitation() {
		String apiUrl = acapyAdminUrl + "/out-of-band/create-invitation";

		// This is a simple, single-use invitation for proof
		String payload = "{\"handshake_protocols\": [\"https://didcomm.org/didexchange/1.1\"]}";
		HttpEntity<String> requestEntity = new HttpEntity<>(payload, createHeaders());

		ResponseEntity<Map> response = restTemplate.exchange(
				apiUrl, HttpMethod.POST, requestEntity, Map.class
		);
		if (response.getStatusCode().is2xxSuccessful() && !(response.getBody().isEmpty())) {
			log.info("Got url");
			return (Map<String, Object>) response.getBody();
		} else {
			throw new RuntimeException("Failed to create invitation: " + response.getStatusCode());
		}
	}

	// NEW METHOD: Get all active connections
	public List<Map<String, Object>> getConnections() {
		String apiUrl = acapyAdminUrl + "/connections?state=active";
		HttpEntity<String> requestEntity = new HttpEntity<>(createHeaders());

		try {
			ResponseEntity<Map<String, List<Map<String, Object>>>> response = restTemplate.exchange(
					apiUrl,
					HttpMethod.GET,
					requestEntity,
					new ParameterizedTypeReference<Map<String, List<Map<String, Object>>>>() {}
			);
			return response.getBody().get("results");
		} catch (Exception e) {
			log.error("Error fetching connections: {}", e.getMessage());
			return Collections.emptyList();
		}
	}
	public void requestProof(String connectionId, List<String> requestedAttributes) {
		String apiUrl = acapyAdminUrl + "/present-proof-2.0/send-request";
		String credDefId = "53eakFU6eyG63R5YMcPkZk:3:CL:10:default";

		// --- DYNAMICALLY BUILD THE REQUEST ---
		Map<String, Object> indyRequest = new HashMap<>();
		indyRequest.put("name", "Proof of University Degree");
		indyRequest.put("version", "1.0");

		// Build requested_attributes
		Map<String, Object> requestedAttrs = new HashMap<>();
		for (int i = 0; i < requestedAttributes.size(); i++) {
			String attrName = requestedAttributes.get(i);
			String attrKey = "attr_" + i; // unique key per attribute

			Map<String, Object> attrInfo = new HashMap<>();
			attrInfo.put("name", attrName);
			attrInfo.put("restrictions", List.of(Map.of("cred_def_id", credDefId)));

			requestedAttrs.put(attrKey, attrInfo);
		}

		indyRequest.put("requested_attributes", requestedAttrs);
		indyRequest.put("requested_predicates", Map.of()); // No numeric conditions

		// Wrap indy request as required by v2
		Map<String, Object> presentationRequest = new HashMap<>();
		presentationRequest.put("indy", indyRequest);

		// Final payload
		Map<String, Object> proofRequestPayload = new HashMap<>();
		proofRequestPayload.put("connection_id", connectionId);
		proofRequestPayload.put("presentation_request", presentationRequest);
		HttpEntity<Map<String, Object>> requestEntity =
				new HttpEntity<>(proofRequestPayload, createHeaders());
		try {
			ResponseEntity<String> response = restTemplate.postForEntity(apiUrl, requestEntity, String.class);
			log.info("proof request sent to connection: {}", connectionId);
			log.debug("Response: {}", response.getBody());
		} catch (Exception e) {
			log.error("Error sending proof request: {}", e.getMessage(), e);
		}
	}

//	public void requestProof(String connectionId) {
//		String apiUrl = acapyAdminUrl + "/present-proof-2.0/send-request";
//
//		// This is the proof request.
//		// It asks for attributes matching the Cred Def ID of the degree.
//		// **IMPORTANT**: Replace with the Cred Def ID you created on the Issuer Agent
//		String credDefId = "53eakFU6eyG63R5YMcPkZk:3:CL:10:default";
//
//		String proofRequestBody = String.format("""
//		{
//		   "connection_id": "%s",
//		   "presentation_request": {
//		    "indy":{
//			     "name": "Proof of University Degree",
//			     "version": "1.0",
//			     "requested_attributes": {
//			       "degree_info": {
//			         "name": "degree_name",
//			         "restrictions": [
//			           { "cred_def_id": "%s" }
//			         ]
//			       },
//			       "student_name": {
//			         "name": "name",
//			         "restrictions": [
//			           { "cred_def_id": "%s" }
//			         ]
//			       }
//			     },
//			     "requested_predicates": {}
//		     }
//		   }
//		 }
//		""", connectionId, credDefId, credDefId);
//
//		HttpEntity<String> requestEntity = new HttpEntity<>(proofRequestBody, createHeaders());
//
//		try {
//			restTemplate.postForEntity(apiUrl, requestEntity, String.class);
//			log.info("Proof request sent to connection: {}", connectionId);
//		} catch (Exception e) {
//			log.error("Error sending proof request: {}", e.getMessage());
//		}
//	}

	public void deleteConnection(String connectionId) {
		String apiUrl = acapyAdminUrl + "/connections/" + connectionId;
		HttpEntity<String> requestEntity = new HttpEntity<>(createHeaders());

		try {
			restTemplate.exchange(apiUrl, HttpMethod.DELETE, requestEntity, String.class);
			proofCache.clearProof(connectionId);
			log.info("Connection delete request sent for: {}", connectionId);
		} catch (Exception e) {
			log.error("Error deleting connection: {}", connectionId, e);
			// Re-throw to be handled by the controller
			throw new RuntimeException("Error deleting connection: " + e.getMessage(), e);
		}
	}
}
