package team.Student.controllers;


import team.Student.service.ProofRequestCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class WalletWebhookController {

	private static final Logger log = LoggerFactory.getLogger(WalletWebhookController.class);

	@Autowired
	private ProofRequestCache proofCache;

	@PostMapping({"/webhooks/topic/{topic}", "/webhooks/topic/{topic}/"})
	public ResponseEntity<String> handleWebhook(@PathVariable String topic, @RequestBody Map<String, Object> payload) {

		log.info("STUDENT Webhook Received for topic [{}]: {}", topic, payload);

		try {
			if ("present_proof_v2_0".equals(topic)) {
				handleProofWebhook(payload);
			}

		} catch (Exception e) {
			log.error("Error processing student webhook for topic: {}", topic, e);
		}
		return ResponseEntity.ok("Webhook received");
	}

	private void handleProofWebhook(Map<String, Object> payload) {
		String state = (String) payload.get("state");
		String presExId = (String) payload.get("pres_ex_id");

		log.info("Student Proof Webhook: ID={} | State={}", presExId, state);

		if ("request-received".equals(state)) {
			// A new request has come in. Store it.
			log.info("New proof request received. Storing in cache: {}", presExId);
			proofCache.store(presExId, payload);
		}

		// If the proof is sent, verified, or rejected, remove it from the cache
		if ("presentation-sent".equals(state) || "done".equals(state) || "abandoned".equals(state)) {
			log.info("Proof request {} is now complete. Removing from cache.", presExId);
			proofCache.remove(presExId);
		}
	}
}