package team.project.dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Map;

/**
 * Represents the ACA-Py v2 Credential Offer Request
 * sent to /issue-credential-2.0/send-offer endpoint.
 *
 * Reference: Aries RFC 0593 - Issue Credential Protocol 2.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AriesCredentialOfferRequest {

	/**
	 * Whether to automatically issue the credential after the holder accepts the offer.
	 */
	@JsonProperty("auto_issue")
	private boolean autoIssue = true;

	/**
	 * Whether to automatically remove the exchange record when complete.
	 */
	@JsonProperty("auto_remove")
	private boolean autoRemove = true;

	/**
	 * The connection ID of the holder (student).
	 */
	@JsonProperty("connection_id")
	private String connectionId;

	/**
	 * Filter specifying the credential format and definition ID.
	 * For Indy: {"indy": {"cred_def_id": "CRED_DEF_ID"}}
	 */
	@JsonProperty("filter")
	private Map<String, Object> filter;

	/**
	 * Credential preview section — includes the actual attribute data.
	 */
	@JsonProperty("credential_preview")
	private CredentialPreview credentialPreview;

	// ---------------- Nested Classes ---------------- //

	/**
	 * Credential preview according to Aries RFC 0593.
	 */
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class CredentialPreview {

		@JsonProperty("@type")
		private String type = "issue-credential/2.0/credential-preview";

		@JsonProperty("attributes")
		private List<CredentialAttribute> attributes;
	}

	/**
	 * Represents a single credential attribute (name-value pair).
	 */
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class CredentialAttribute {

		@JsonProperty("name")
		private String name;

		@JsonProperty("value")
		private String value;
	}
}
