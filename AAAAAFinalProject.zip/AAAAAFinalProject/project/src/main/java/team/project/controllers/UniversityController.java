package team.project.controllers;
import lombok.extern.slf4j.Slf4j;
import team.project.service.AriesService;
import team.project.entity.Student;
import team.project.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable; // Import PathVariable
import org.springframework.web.bind.annotation.PostMapping; // Import PostMapping
import org.springframework.web.servlet.mvc.support.RedirectAttributes; // Import RedirectAttributes
import java.util.List;
import java.util.Map;
import java.util.Optional;


@Controller
@Slf4j
public class UniversityController {

	@Autowired
	private StudentRepository studentRepository;
	@Autowired // Inject AriesService
	private AriesService ariesService;

	@GetMapping("/dashboard")
	public String showDashboard(Model model) {
		List<Student> students = studentRepository.findAll();
		model.addAttribute("students", students);
		model.addAttribute("pageTitle", "University Dashboard");
		return "dashboard"; // Corresponds to dashboard.html
	}

	// Handles the form submission from the "Issue Degree" button
	@PostMapping("/issue-degree/{studentId}")
	public String issueDegree(@PathVariable Long studentId, RedirectAttributes redirectAttributes) {
		log.info("Received request to issue degree for student ID: {}", studentId);
		Optional<Student> studentOptional = studentRepository.findById(studentId);

		if (studentOptional.isPresent()) {
			Student student = studentOptional.get();
			if(student.isDegreeIssued()) return "redirect:/dashboard";
			try {
				// Call the AriesService to initiate issuance
				ariesService.issueDegreeCredential(student);
				redirectAttributes.addFlashAttribute("successMessage", "Credential offer sent to agent for student: " + student.getName());
				log.info("Credential offer process initiated for student ID: {}", studentId);
			} catch (Exception e) {
				log.error("Error initiating credential issuance for student ID: {}", studentId, e);
			}
		} else {
			log.warn("Student not found for ID: {}", studentId);
			redirectAttributes.addFlashAttribute("errorMessage", "Student not found with ID: " + studentId);
		}

		return "redirect:/dashboard"; // Redirect back to the dashboard page
	}

	@GetMapping("/connect/{studentId}")
	public String generateInvitation(@PathVariable Long studentId, Model model, RedirectAttributes redirectAttributes) {
		Student student = studentRepository.findById(studentId)
				.orElseThrow(() -> new RuntimeException("Student not found"));

		try {
			// 1. Call Aries to get the invitation object
			Map<String, Object> response = ariesService.createInvitation(student.getId().toString());

			// 2. Extract the invitation URL and record ID
			String invitationUrl = (String) response.get("invitation_url");
			//String connectionRecordId = (String) response.get("connection_id");

			// 3. Save the initial record ID (connection_id) to the student record
			//student.setConnectionId(connectionRecordId);
			//studentRepository.save(student);

			model.addAttribute("invitationUrl", invitationUrl);
			model.addAttribute("pageTitle", "Connect Student");
			model.addAttribute("studentName", student.getName());

			return "invitation"; // New Thymeleaf template
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("errorMessage", "Error creating invitation: " + e.getMessage());
			return "redirect:/dashboard";
		}
	}
}