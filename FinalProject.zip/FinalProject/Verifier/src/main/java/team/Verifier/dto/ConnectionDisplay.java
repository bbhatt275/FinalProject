package team.Verifier.dto;
import lombok.Data;
import java.util.Map;

@Data
public class ConnectionDisplay {
	private String connectionId;
	private String alias;
	private String state;
	private Map<String, String> verifiedData;
}