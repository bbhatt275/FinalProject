INSERT INTO student (name, email, degree_issued, connection_id)
VALUES ('Bharat Bhatt', 'bharat@example.com', false, NULL);

INSERT INTO student (name, email, degree_issued, connection_id)
VALUES ('Chetan Palariya', 'chetan@example.com', false, NULL);

INSERT INTO student (name, email, degree_issued, connection_id)
VALUES ('Karan Kiroula', 'karan@example.com', false, NULL);