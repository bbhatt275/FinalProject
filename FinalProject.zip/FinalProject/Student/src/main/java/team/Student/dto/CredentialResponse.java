package team.Student.dto;

import lombok.Data;
import java.util.List;

@Data
public class CredentialResponse {
	private List<CredentialRecord> results;
}
