package team.project.repository;

import team.project.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
	// Spring Data JPA automatically provides methods like findAll(), findById(), save(), etc.
	// You can add custom query methods here later if needed.
	Optional<Student> findByConnectionId(String connectionId);
}
