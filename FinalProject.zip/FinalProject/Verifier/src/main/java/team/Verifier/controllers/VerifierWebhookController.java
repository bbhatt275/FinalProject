package team.Verifier.controllers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import team.Verifier.service.VerifiedProofCache;

import java.util.HashMap;
import java.util.Map;

@RestController
public class VerifierWebhookController {

	private static final Logger log = LoggerFactory.getLogger(VerifierWebhookController.class);

	@Autowired
	private VerifiedProofCache proofCache;

	@PostMapping({"/webhooks/topic/{topic}", "/webhooks/topic/{topic}/"})
	public ResponseEntity<String> handleWebhook(@PathVariable String topic, @RequestBody Map<String, Object> payload) {

		log.info("Verifier Webhook Received for topic [{}]: {}", topic, payload);

		try {
			switch (topic) {
				case "connections":
					// We can just log that a connection became active
					if ("active".equals(payload.get("state"))) {
						log.info("Connection {} is now active.", payload.get("connection_id"));
					}
					break;
				case "present_proof_v2_0":
					handleProofWebhook(payload);
					break;
				default:
					log.warn("Received webhook for unhandled topic: {}", topic);
			}
		} catch (Exception e) {
			log.error("Error processing webhook for topic: {}", topic, e);
		}

		return ResponseEntity.ok("Webhook received successfully");
	}

	private void handleProofWebhook(Map<String, Object> payload) {
		String state = (String) payload.get("state");
		String connectionId = (String) payload.get("connection_id");
		log.info("Proof Webhook: ConnID={} | State={}", connectionId, state);

		// This is the final verification step!
		if ("done".equals(state)) {
			// The 'verified' field will be "true" or "false"
			boolean isVerified = Boolean.parseBoolean((String) payload.get("verified"));
			if (isVerified) {
				log.info("PROOF VERIFIED for Connection ID: {}", connectionId);
				// In a real app, you would update your database
				// to show this applicant is verified
				// --- PARSE THE VERIFIED DATA ---
				try {
					Map<String, Object> byFormat = (Map<String, Object>) payload.get("by_format");
					Map<String ,Object> presentation = (Map<String, Object>) byFormat.get("pres");
					// v2 wraps indy presentation data under "indy"
					Map<String, Object> indy = (Map<String, Object>) presentation.get("indy");

					Map<String, Object> requestedProof = (Map<String, Object>) indy.get("requested_proof");
					Map<String, Object> revealedAttrs = (Map<String, Object>) requestedProof.get("revealed_attrs");

					Map<String, String> verifiedData = new HashMap<>();
					for (Map.Entry<String, Object> entry : revealedAttrs.entrySet()) {
						Map<String, String> attrDetails = (Map<String, String>) entry.getValue();
						String attrValue = attrDetails.get("raw"); // Get the verified value
						verifiedData.put(entry.getKey(), attrValue);
					}

					// --- STORE IN CACHE ---
					proofCache.storeProof(connectionId, verifiedData);
					log.info("Stored verified data for {}: {}", connectionId, verifiedData);

				} catch (Exception e) {
					log.error("Error parsing verified attributes from proof webhook: {}", e.getMessage());
				}
			} else {
				log.warn("PROOF NOT VERIFIED for Connection ID: {}", connectionId);
			}
		}
	}
}