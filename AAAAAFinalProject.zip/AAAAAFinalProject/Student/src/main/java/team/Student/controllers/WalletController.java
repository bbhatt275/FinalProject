package team.Student.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import team.Student.dto.CredentialRecord;
import team.Student.service.ProofRequestCache;
import team.Student.wallet.WalletAriesService;

import java.util.List;

@Controller
public class WalletController {

	@Autowired
	private WalletAriesService ariesService;
	@Autowired
	private ProofRequestCache proofCache;

	@GetMapping("/")
	public String home(Model model) {
		model.addAttribute("pageTitle", "Student Digital Wallet");
		// Fetch credentials and add them to the model
		List<CredentialRecord> credentials = ariesService.getCredentials();
		model.addAttribute("credentials", credentials);
		model.addAttribute("pendingProofs", proofCache.getAll());
		return "index"; // Corresponds to index.html
	}

	@PostMapping("/receive-invitation")
	public String receiveInvitation(@RequestParam String invitationUrl, RedirectAttributes redirectAttributes) {
		try {
			// 1. Fetch the JSON from the URL
			String invitationJson = ariesService.decodeInvitationUrl(invitationUrl);

			// 2. Post the full JSON to the Student Agent
			String connectionId = ariesService.receiveInvitation(invitationJson);

			redirectAttributes.addFlashAttribute("successMessage",
					"Invitation accepted! Connection ID: " + connectionId);

		} catch (Exception e) {
			e.printStackTrace();
			redirectAttributes.addFlashAttribute("errorMessage",
					"Failed to accept invitation: " + e.getMessage());
		}
		return "redirect:/";
	}

	@PostMapping("/accept-proof/{presExId}")
	public String acceptProof(@PathVariable String presExId, RedirectAttributes redirectAttributes) {
		try {
			if(ariesService.sendProof(presExId)){
				redirectAttributes.addFlashAttribute("successMessage", "Proof sent successfully!");
			}
			else redirectAttributes.addFlashAttribute("errorMessage", "No requested proof!");
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("errorMessage", "Error sending proof: " + e.getMessage());
		}
		return "redirect:/";
	}

	@PostMapping("/reject-proof/{presExId}")
	public String rejectProof(@PathVariable String presExId, RedirectAttributes redirectAttributes) {
		try {
			ariesService.rejectProof(presExId);
			redirectAttributes.addFlashAttribute("successMessage", "Proof request rejected.");
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("errorMessage", "Error rejecting proof: " + e.getMessage());
		}
		return "redirect:/";
	}
}
