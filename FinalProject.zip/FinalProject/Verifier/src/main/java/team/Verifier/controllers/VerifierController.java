package team.Verifier.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import team.Verifier.dto.ConnectionDisplay;
import team.Verifier.service.VerifiedProofCache;
import team.Verifier.service.VerifierAriesService;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
public class VerifierController {
	@Autowired
	private VerifiedProofCache proofCache;
	@Autowired
	private VerifierAriesService ariesService;

	// This will be our main dashboard
	@GetMapping("/")
	public String home(Model model) {
		model.addAttribute("pageTitle", "Employer Verification Portal");
		List<Map<String, Object>> connections = ariesService.getConnections();
		model.addAttribute("connections", connections);
		// Create a new list to hold display objects
		List<ConnectionDisplay> connectionDisplays = new ArrayList<>();

		for (Map<String, Object> conn : connections) {
			ConnectionDisplay display = new ConnectionDisplay();
			String connectionId = (String) conn.get("connection_id");

			display.setConnectionId(connectionId);
			display.setAlias((String) conn.get("their_label"));
			display.setState((String) conn.get("state"));
			Map<String,String> proof = proofCache.getProof(connectionId);
			// Check the cache for verified data
			display.setVerifiedData(proof);
			connectionDisplays.add(display);
		}

		model.addAttribute("connections", connectionDisplays);
		return "index";
	}

	// This endpoint creates the connection invitation
	@GetMapping("/create-invitation")
	public String createInvitation(Model model) {
		Map<String, Object> invitationResponse = ariesService.createConnectionInvitation();

		String invitationUrl = (String) invitationResponse.get("invitation_url");
		String connectionId = (String) invitationResponse.get("connection_id");

		model.addAttribute("pageTitle", "Connect with Applicant");
		model.addAttribute("invitationUrl", invitationUrl);
		model.addAttribute("connectionId", connectionId);

		// We'll use this to display the QR code
		return "invitation";
	}
	// NEW METHOD: Handles the "Request Proof" button click
	@PostMapping("/request-proof/{connectionId}")
	public String requestProof(
			@PathVariable String connectionId,
			@RequestParam(required = false) List<String> attributes, // Get attributes from form
			RedirectAttributes redirectAttributes) {

		if (attributes == null || attributes.isEmpty()) {
			proofCache.clearProof(connectionId);
			redirectAttributes.addFlashAttribute("errorMessage", "You must select at least one attribute to verify.");
			return "redirect:/";
		}

		try {
			// Clear any old proof data before sending a new request
			proofCache.clearProof(connectionId);

			ariesService.requestProof(connectionId, attributes);
			redirectAttributes.addFlashAttribute("successMessage", "Proof request sent for: " + attributes);
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("errorMessage", "Error sending proof request: " + e.getMessage());
		}
		return "redirect:/";
	}
	@PostMapping("/delete-connection/{connectionId}")
	public String deleteConnection(@PathVariable String connectionId, RedirectAttributes redirectAttributes) {
		try {
			ariesService.deleteConnection(connectionId);
			redirectAttributes.addFlashAttribute("successMessage", "Connection deleted: " + connectionId);
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("errorMessage", "Error deleting connection: " + e.getMessage());
		}
		return "redirect:/"; // Redirect back to the homepage
	}
}