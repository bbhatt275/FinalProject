package team.project.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
@Data
@Entity
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String name;
	private String email;
	private boolean degreeIssued = false; // To track credential status
	private String connectionId;

	// Constructors (Lombok generates default, add others if needed)
	public Student() {}

	public Student(String name, String email) {
		this.name = name;
		this.email = email;
	}

}