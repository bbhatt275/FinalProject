package team.Student.service;
import org.springframework.stereotype.Component;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A simple in-memory cache to hold pending proof requests.
 * Key: presentation_exchange_id
 * Value: The full webhook payload (which contains the request details)
 */
@Component
public class ProofRequestCache {

	private static final Map<String, Map<String, Object>> cache = new ConcurrentHashMap<>();

	public void store(String presentationExchangeId, Map<String, Object> payload) {
		cache.put(presentationExchangeId, payload);
	}

	public Map<String, Object> get(String presentationExchangeId) {
		return cache.get(presentationExchangeId);
	}

	public void remove(String presentationExchangeId) {
		cache.remove(presentationExchangeId);
	}

	public Map<String, Map<String, Object>> getAll() {
		return Map.copyOf(cache);
	}
}