-- Define the table structure for the Student entity
-- Drop table if it exists (optional, but good for clean runs with H2)
DROP TABLE IF EXISTS student;

-- Create the student table
CREATE TABLE student (
    id BIGINT AUTO_INCREMENT PRIMARY KEY, -- Auto-incrementing primary key
    name VARCHAR(255) NOT NULL,          -- Student's name
    email VARCHAR(255) UNIQUE,           -- Student's email (optional: add UNIQUE constraint if desired)
    degree_issued BOOLEAN DEFAULT FALSE,  -- Flag to track credential status
    connection_id VARCHAR(255)
);