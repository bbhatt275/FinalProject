package team.project.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import team.project.entity.Student;

import java.util.Collections;
import team.project.dto.AriesCredentialOfferRequest; // We'll create this DTO
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import java.util.List;
import java.util.Map;


@Service
@Slf4j
public class AriesService {
	@Autowired
	private RestTemplate restTemplate;
	@Value("${acapy.admin.url}")
	private String acapyAdminUrl;
	@Value("${acapy.admin.api-key}")
	private String acapyAdminApiKey;

	// You might need to find the correct Credential Definition ID from your agent
	// For now, let's hardcode a placeholder. Get the real one via ACA-Py API later.
	// Example: Replace with the CredDef ID created when the agent started or via API.
	private final String DEGREE_CREDENTIAL_DEFINITION_ID = "53eakFU6eyG63R5YMcPkZk:3:CL:10:default"; // IMPORTANT

	public void issueDegreeCredential(Student student) {
		log.info("Attempting to issue degree credential for student ID: {}", student.getId());

		String apiUrl = acapyAdminUrl + "/issue-credential-2.0/send-offer";

		// Prepare headers
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		if (acapyAdminApiKey != null && !acapyAdminApiKey.isEmpty()) {
			headers.set("X-API-Key", acapyAdminApiKey);
		}


		List<AriesCredentialOfferRequest.CredentialAttribute> attributes = List.of(
				new AriesCredentialOfferRequest.CredentialAttribute("student_id", String.valueOf(student.getId())),
				new AriesCredentialOfferRequest.CredentialAttribute("name", student.getName()),
				new AriesCredentialOfferRequest.CredentialAttribute("email", student.getEmail()),
				new AriesCredentialOfferRequest.CredentialAttribute("degree_name", "B.Tech Computer Science"),
				new AriesCredentialOfferRequest.CredentialAttribute("issue_date", java.time.LocalDate.now().toString())
		);


		Map<String, Object> filter = Map.of(
				"indy", Map.of("cred_def_id", DEGREE_CREDENTIAL_DEFINITION_ID)
		);

		AriesCredentialOfferRequest.CredentialPreview preview =
				new AriesCredentialOfferRequest.CredentialPreview(
						"issue-credential/2.0/credential-preview",
						attributes
				);

		AriesCredentialOfferRequest offerRequest = new AriesCredentialOfferRequest(
				false,                      // autoIssue
				true,                       // autoRemove
				student.getConnectionId(),  // connection_id
				filter,                     // filter
				preview                     // credential_preview
		);


		HttpEntity<AriesCredentialOfferRequest> requestEntity = new HttpEntity<>(offerRequest, headers);

		try {
			// Make the API call
			log.debug("Sending credential offer request to: {}", apiUrl);
			log.debug("Request Payload: {}", offerRequest); // Be careful logging sensitive data
			ResponseEntity<String> response = restTemplate.exchange(
					apiUrl,
					HttpMethod.POST,
					requestEntity,
					String.class // Expecting a String response body (often JSON)
			);

			log.info("ACA-Py API response status: {}", response.getStatusCode());
			log.info("ACA-Py API response body: {}", response.getBody());

			if (!response.getStatusCode().is2xxSuccessful()) {
				log.error("Failed to send credential offer. Status: {}, Body: {}", response.getStatusCode(), response.getBody());
				// Handle error appropriately - maybe throw a custom exception
			} else {
				log.info("Successfully sent credential offer request for student ID: {}", student.getId());
				// Later: Update student status in DB?
			}

		} catch (RestClientException e) {
			log.error("Error calling ACA-Py API at {}: {}", apiUrl, e.getMessage());
			// Handle connection errors, etc.
		}
	}

	public Map<String, Object> createInvitation(String studentAlias) {
		log.info("Requesting invitation for alias: {}", studentAlias);
		String apiUrl = acapyAdminUrl + "/out-of-band/create-invitation";

		HttpHeaders headers = new HttpHeaders();
		headers.set("X-API-Key", acapyAdminApiKey);
		headers.setContentType(MediaType.APPLICATION_JSON);

		// Request Body: Use did:peer:2 for a resolvable DID which is good practice.
		String invitationPayload = "{"
				+ "\"alias\": \"" + studentAlias + "\","
				+ "\"handshake_protocols\": [\"https://didcomm.org/didexchange/1.1\"],"
				+ "\"multi_use\": true" // Important: allows the connection to be reused
				+ "}";

		HttpEntity<String> requestEntity = new HttpEntity<>(invitationPayload, headers);

		ResponseEntity<Map> response = restTemplate.exchange(
				apiUrl,
				HttpMethod.POST,
				requestEntity,
				Map.class // Receive the entire response map
		);
		//we get response here itself but webhook is still called
		if (response.getStatusCode().is2xxSuccessful() && !(response.getBody().isEmpty())) {
			log.info("Got url");
			return (Map<String, Object>) response.getBody();
		} else {
			throw new RuntimeException("Failed to create invitation: " + response.getStatusCode());
		}
	}
	public void acceptConnectionRequest(String connectionId) {
		try {
			String apiUrl = "http://localhost:8021/didexchange/" + connectionId + "/accept-request";

			HttpHeaders headers = new HttpHeaders();
			headers.set("X-API-Key", acapyAdminApiKey);
			headers.setContentType(MediaType.APPLICATION_JSON);

			HttpEntity<String> request = new HttpEntity<>("{}", headers);

			restTemplate.postForEntity(apiUrl, request, Map.class);
			log.info("Sent accept-request for connection ID {}", connectionId);
		} catch (Exception e) {
			log.error("Failed to accept connection request for connection ID {}", connectionId, e);
		}
	}

	public void issueCredential(String credExId) {
		String apiUrl = acapyAdminUrl + "/issue-credential-2.0/records/" + credExId + "/issue";

		HttpHeaders headers = new HttpHeaders();
		headers.set("X-API-Key", acapyAdminApiKey);
		headers.setContentType(MediaType.APPLICATION_JSON);

		try {
			log.info("Issuing credential via ACA-Py for exchange ID {}", credExId);
			restTemplate.postForEntity(apiUrl, new HttpEntity<>("{}", headers), String.class);
			log.info("Credential issued successfully for exchange ID {}", credExId);
		} catch (Exception e) {
			log.error("Error issuing credential for exchange ID {}: {}", credExId, e.getMessage());
			throw new RuntimeException(e);
		}
	}

}
