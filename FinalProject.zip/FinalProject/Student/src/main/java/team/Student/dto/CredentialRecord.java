package team.Student.dto;

import lombok.Data;
import java.util.Map;
@Data
public class CredentialRecord {
	// This will hold the credential attributes like "name", "email", "degree_name"
	private Map<String, String> attrs;

	// We can also store other useful info
	private String schema_id;
	private String cred_def_id;
	private String referent; // The unique ID for this credential in the wallet
}