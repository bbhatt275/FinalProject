package team.Student.wallet;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import team.Student.dto.CredentialRecord;
import team.Student.dto.CredentialResponse;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@Slf4j
@Service
public class WalletAriesService {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ObjectMapper objectMapper; // For pretty JSON conversion

	// Student Agent's Admin API
	@Value("${acapy.admin.url}")
	private String acapyAdminUrl;

	@Value("${acapy.admin.api-key}")
	private String acapyAdminApiKey;

	private HttpHeaders createHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("X-API-Key", acapyAdminApiKey);
		headers.setContentType(MediaType.APPLICATION_JSON);
		return headers;
	}

	/**
	 * Decodes an Out-of-Band invitation URL into its raw JSON form.
	 */
	public String decodeInvitationUrl(String invitationUrl) {
		try {
			log.info("Decoding invitation URL: {}", invitationUrl);

			// Extract base64 string from ?oob= or ?c_i=
			String encodedPart = null;
			if (invitationUrl.contains("?oob=")) {
				encodedPart = invitationUrl.substring(invitationUrl.indexOf("?oob=") + 5);
			} else if (invitationUrl.contains("?c_i=")) {
				encodedPart = invitationUrl.substring(invitationUrl.indexOf("?c_i=") + 5);
			}

			if (encodedPart == null || encodedPart.isEmpty()) {
				throw new IllegalArgumentException("Invalid invitation URL: missing ?oob= or ?c_i= parameter");
			}

			// URL-decode, then Base64-decode
			String urlDecoded = URLDecoder.decode(encodedPart, StandardCharsets.UTF_8);
			byte[] base64Decoded = Base64.getUrlDecoder().decode(urlDecoded);

			String invitationJson = new String(base64Decoded, StandardCharsets.UTF_8);
			log.debug("Decoded invitation JSON: {}", invitationJson);

			// Optional: format JSON nicely
			Map<String, Object> map = objectMapper.readValue(invitationJson, Map.class);
			return objectMapper.writeValueAsString(map);

		} catch (Exception e) {
			log.error("Failed to decode invitation URL", e);
			throw new RuntimeException("Error decoding invitation URL: " + e.getMessage(), e);
		}
	}

	/**
	 * Step 2: Sends the decoded invitation JSON to the Student Agent.
	 */
	public String receiveInvitation(String invitationJson) {
		try {
			log.info("Sending invitation JSON to Student Agent...");

			String apiUrl = acapyAdminUrl + "/out-of-band/receive-invitation";

			HttpHeaders headers = new HttpHeaders();
			headers.set("X-API-Key", acapyAdminApiKey);
			headers.setContentType(MediaType.APPLICATION_JSON);

			HttpEntity<String> requestEntity = new HttpEntity<>(invitationJson, headers);

			ResponseEntity<Map> response = restTemplate.exchange(
					apiUrl,
					HttpMethod.POST,
					requestEntity,
					Map.class
			);

			Map<String, Object> body = response.getBody();
			if (body != null && body.containsKey("connection_id")) {
				String connectionId = (String) body.get("connection_id");
				log.info("Successfully received invitation. Connection ID: {}", connectionId);
				return connectionId;
			}

			throw new RuntimeException("Unexpected response from agent: " + body);

		} catch (Exception e) {
			log.error("Error sending invitation to Student Agent", e);
			throw new RuntimeException("Failed to send invitation: " + e.getMessage(), e);
		}
	}

	// fetch received credentials
	public List<CredentialRecord> getCredentials() {
		log.info("Fetching credentials from Student Agent");
		String apiUrl = acapyAdminUrl + "/credentials";

		HttpHeaders headers = new HttpHeaders();
		headers.set("X-API-Key", acapyAdminApiKey);
		headers.setAccept(List.of(MediaType.APPLICATION_JSON));

		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		try {
			// We expect a list of CredentialRecord objects
			ResponseEntity<CredentialResponse> response = restTemplate.exchange(
					apiUrl,
					HttpMethod.GET,
					requestEntity,
					new ParameterizedTypeReference<CredentialResponse>() {} // This handles the List<T>
			);
			CredentialResponse body = (CredentialResponse) response.getBody();
			if (body != null) {
				log.info("Successfully fetched {} credentials", body.getResults().size());
				return body.getResults();
			}
		} catch (Exception e) {
			log.error("Error fetching credentials: {}", e.getMessage());
		}
		return List.of(); // Return an empty list on failure
	}

	/**
	 * ACA-Py will automatically find the matching credentials.
	 */
	public boolean sendProof(String presExId) {
		try {
			// Fetch credentials that satisfy the proof request
			String credsUrl = acapyAdminUrl + "/present-proof-2.0/records/" + presExId + "/credentials";
			ResponseEntity<List> credsResp = restTemplate.exchange(
					credsUrl, HttpMethod.GET, new HttpEntity<>(createHeaders()), List.class);

			List<Map<String, Object>> creds = credsResp.getBody();

			if (creds == null || creds.isEmpty()) {
				log.error("No matching credentials found for proof {}", presExId);
				return false;
			}
			// Auto-select the first credential
			Map<String, Object> entry = creds.get(0);
			Map<String, Object> credInfo = (Map<String, Object>) entry.get("cred_info");
			String credId = (String) credInfo.get("referent");

			List<String> referents =
					(List<String>) entry.get("presentation_referents");

			// Build the indy payload
			Map<String, Object> indy = new HashMap<>();
			Map<String, Object> requestedAttrs = new HashMap<>();

			for (String ref : referents) {
				Map<String, Object> m = new HashMap<>();
				m.put("cred_id", credId);
				m.put("revealed", true);
				requestedAttrs.put(ref, m);
			}

			indy.put("requested_attributes", requestedAttrs);
			indy.put("requested_predicates", new HashMap<>());
			indy.put("self_attested_attributes", new HashMap<>());

			Map<String, Object> payload = new HashMap<>();
			payload.put("indy", indy);

			// 3. POST send-presentation
			String url = acapyAdminUrl + "/present-proof-2.0/records/" + presExId + "/send-presentation";
			HttpEntity<Map<String, Object>> entity = new HttpEntity<>(payload, createHeaders());
			restTemplate.postForEntity(url, entity, String.class);

			log.info("Presentation sent for {}", presExId);
			return true;

		} catch (Exception e) {
			log.error("Error: {}", e.getMessage(), e);
			return false;
		}
	}


	/**
	 Rejects or abandons the proof request.
	 */
	public void rejectProof(String presentationExchangeId) {
		String apiUrl = acapyAdminUrl + "/present-proof-2.0/records/" + presentationExchangeId + "/problem-report";
		log.info("Rejecting proof request: {}", presentationExchangeId);

		// Send a simple problem report
		String payload = """
	    {
	      "description": "Presentation request rejected by user."
	    }
	    """;
		HttpEntity<String> requestEntity = new HttpEntity<>(payload, createHeaders());

		try {
			restTemplate.postForEntity(apiUrl, requestEntity, String.class);
			log.info("Proof request rejected.");
		} catch (Exception e) {
			log.error("Error rejecting proof request: {}", e.getMessage());
		}
	}
}
